const boxes = document.querySelectorAll('.box');

boxes.forEach(box => {
  box.addEventListener('click', () => {
    boxes.forEach(b => b.classList.remove('expanded'));
    box.classList.add('expanded');
  });
});

document.querySelectorAll('.color').forEach(color => {
  color.addEventListener('click', e => {
    e.stopPropagation();
    const selectedColor = color.dataset.color;
    const parentBox = color.closest('.box');
    parentBox.style.backgroundColor = selectedColor;
  });
});

document.querySelectorAll('.sizes button').forEach(button => {
  button.addEventListener('click', e => {
    e.stopPropagation();
    alert(`Size selected: ${button.textContent}`);
  });
});
